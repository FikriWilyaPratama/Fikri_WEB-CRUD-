<?php

include 'koneksi.php';

if ($_GET['proses'] == 'insert') {
    //query insert
    if (isset($_POST["submit"])) {
        $nama_prodi = $_POST['nama_prodi'];
        $jenjang_studi = $_POST['jenjang_studi'];
        $keterangan=$_POST['keterangan'];
    
        $query="INSERT INTO prodi(nama_prodi,jenjang_studi,keterangan) VALUES ('$nama_prodi','$jenjang_studi','$keterangan')";
    
        $sql = $db->query($query);
    
        if ($sql) {
            header("Location: index.php?page=prodi");
        } else {
            echo "Simpan data failed " .$db->error;
        }
        }
}

if ($_GET['proses'] == 'update') {
    //query update
    if (isset($_POST["submit"])) {
        $id = $_POST['id'];
        $nama_prodi = $_POST['nama_prodi'];
        $jenjang_studi=$_POST['jenjang_studi'];
        $keterangan=$_POST['keterangan'];

        $query = "UPDATE prodi SET nama_prodi = '$nama_prodi', jenjang_studi = '$jenjang_studi', keterangan = '$keterangan' WHERE id = $id";

        if ($db->query($query) === TRUE) {
            header("Location: index.php?page=prodi");
        } else {
            echo "Update data gagal.".$db->error;
        }
    }
}

if ($_GET['proses'] == 'delete') {
    //query delete
    if (isset($_GET['id'])) {
        $id = $_GET['id'];
        $query = "DELETE FROM prodi WHERE id = '$id'";

        if ($db->query($query) === TRUE) {
            header ("Location: index.php?page=prodi");
        } else {
            echo "Gagal menghapus data!" . $db->error;
        }
    }
}