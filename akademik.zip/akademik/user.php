<?php
$aksi=isset($_GET['aksi']) ? $_GET['aksi'] : 'list';
switch ($aksi) {
    case 'list':
        # list user
?>
<h2>Data User</h2>
<?php
if ($_SESSION['level']== 'admin'){
?>
        <a href="index.php?page=user&aksi=input" class="btn btn-primary mb-3">Tambah User</a>
<?php
}
?>
            <table class="table table-bordered table-warning" id="example">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Username</th>
                    <th>Nama</th>
                    <th>Level</th>
        

                    <?php
                if ($_SESSION['level']== 'admin'){
                    ?>
                    <th>Aksi</th>
                    <?php
                    }
                    ?>
                </tr>
            </thead>

            <tbody>
                <?php
                $query = "SELECT * FROM user ORDER BY nama";
                $result = $db->query($query);

                $nomor = 1;
                foreach ($result as $row) :
                ?>
                    <tr>
                        <td><?= $nomor++ ?></td>
                        <td><?= $row['username'] ?></td>
                        <td><?= $row['nama'] ?></td>
                        <td><?= $row['level'] ?></td>
                        

                        <?php
                if ($_SESSION['level']== 'admin'){
                    ?>
                            <td class="text-nowrap">
                            <a href="index.php?page=user&aksi=edit&username=<?= $row['username'] ?>" class="btn btn-warning">Edit</a>
                            <a href="proses_user.php?proses=delete&username=<?= $row['username'] ?>" onclick="return confirm('Apakah yakin hapus data ini?')" class="btn btn-danger">Hapus</a>
                        </td>
                        <?php
                    }
                    ?>

                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
<?php
        break;
    case 'input':
        # form input
?>
<h2>Tambah User</h2>
<form action="proses_user.php?proses=insert" method="POST">
            <div class="form-group">
                <label for="username">Uername:</label>
                <input type="text" class="form-control" name="username" id="username" required>
            </div>
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" name="nama" id="nama" required>
            </div>

            <div class="form-group">
                <label for="password">Password:</label>
               <input name="password" id="password" class="form-control"required>
            </div>

            <div class="form-group">
                <label for="level">Level:</label>
               <select name="level" id="level" class="form-select">
                <option value="">-Pilih Level-</option>
                <option value="admin">Admin</option>
                <option value="user">User</option>
               </select>
            </div>
            <input type="submit" name="submit" value="Simpan" class="btn btn-primary my-2">
            <a href="index.php?page=user" class="btn btn-success my-2">Kembali</a>
        </form>
   
<?php
        break;
    case 'edit':
        # form edit
        $username = $_GET['username'];
        $query = "SELECT * FROM user WHERE username='$username'";
        $result = $db->query($query);
        $row = $result->fetch_assoc();
?>
<h2>Edit User</h2>
        <form action="proses_user.php?proses=update" method="POST">
            <div class="form-group mt-3 mb-2">
                <label for="username">Username:</label>
                <input type="text" class="form-control" name="username" id="username" value="<?php echo $row['username']; ?>" required readonly>
            </div>
            <div class="form-group mt-3 mb-2">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" name="nama" id="nama" value="<?php echo $row['nama']; ?>" required>
            </div>
            <div class="form-group mt-3 mb-2">
                <label for="password">Password:</label>
                <input type="text" class="form-control" name="password" id="password">
            </div>
            <div class="form-group mt-3 mb-2">
                <label for="password">Confirm Password:</label>
                <input type="text" class="form-control" name="confirm" id="password">
            </div>
            <div class="form-group mt-3 mb-2">
                <label for="level">Level:</label>
                <select name="level" id="level" class="form-select">
                    <option value="admin" <?= ($row['level']=='admin') ? 'selected' : ''?>>admin</option>
                    <option value="user" <?= ($row['level']=='user') ? 'selected' : ''?>>user</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary mt-2">Update</button>
            <a href="index.php?page=user" class="btn btn-warning mt-2">Kembali</a>
        </form>

<?php
        break;
}
?>

