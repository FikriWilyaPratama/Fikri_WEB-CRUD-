<?php
$aksi=isset($_GET['aksi']) ? $_GET['aksi'] : 'list';
switch ($aksi) {
    case 'list':
        # list mahasiswa
?>
<h2>Data Mahasiswa</h2>
<?php
if ($_SESSION['level']== 'admin'){
?>
        <a href="index.php?page=mahasiswa&aksi=input" class="btn btn-primary mb-3">Tambah Mahasiswa</a>
<?php
}
?>
            <table class="table table-bordered table-warning" id="example">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Tanggal Lahir</th>
                    <th>Prodi</th>
                    <th>Jenis Kelamin</th>
                    <th>Hobi</th>
                    <th>Alamat</th>

                    <?php
                if ($_SESSION['level']== 'admin'){
                    ?>
                    <th>Aksi</th>
                    <?php
                    }
                    ?>
                </tr>
            </thead>

            <tbody>
                <?php
                $query = "SELECT * FROM mahasiswa,prodi WHERE mahasiswa.prodi_id = prodi.id ORDER BY nama_mhs";
                $result = $db->query($query);

                $nomor = 1;
                foreach ($result as $row) :
                ?>
                    <tr>
                        <td><?= $nomor++ ?></td>
                        <td><?= $row['nim'] ?></td>
                        <td><?= $row['nama_mhs'] ?></td>
                        <td><?= $row['tgl_lahir'] ?></td>
                        <td><?= $row['nama_prodi'] ?></td>
                        <td><?= $row['jenis_kelamin'] ?></td>
                        <td><?= $row['hobi'] ?></td>
                        <td><?= $row['alamat'] ?></td>
                        

                        <?php
                if ($_SESSION['level']== 'admin'){
                    ?>
                            <td class="text-nowrap">
                            <a href="index.php?page=mahasiswa&aksi=edit&nim=<?= $row['nim'] ?>" class="btn btn-warning">Edit</a>
                            <a href="proses_mahasiswa.php?proses=delete&nim=<?= $row['nim'] ?>" onclick="return confirm('Apakah yakin hapus data ini?')" class="btn btn-danger">Hapus</a>
                        </td>
                        <?php
                    }
                    ?>

                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
<?php
        break;
    case 'input':
        # form input
?>
<h2>Tambah Mahasiswa</h2>
        <form action="proses_mahasiswa.php?proses=insert" method="POST">
            <div class="form-group">
                <label for="nim">NIM:</label>
                <input type="text" class="form-control" name="nim" id="nim" required>
            </div>
            <div class="form-group">
                <label for="nama_mhs">Nama:</label>
                <input type="text" class="form-control" name="nama_mhs" id="nama_mhs" required>
            </div>

            <div class="form-group">
                <label for="prodi">Program Prodi:</label>
               <select name="prodi_id" id="prodi" class="form-select">
                <option value="">-Pilih Prodi-</option>
                <?php 
                $prodi=mysqli_query($db,"SELECT * FROM prodi");
                while ($data_prodi=mysqli_fetch_array($prodi)){
                        echo "<option value=".$data_prodi['id'].">".$data_prodi['nama_prodi']."</option>";
                }
                ?>
               </select>
            </div>

            <div class="form-group">
                <label for="tgl_lahir">Tanggal Lahir:</label>
                <div class="form-inline">
                    <select class="" name="tgl_lahir" id="tgl_lahir" required>
                        <option value="">DD</option>
                        <?php
                        for ($i = 1; $i <= 31; $i++) {
                            echo "<option value='$i'>$i</option>";
                        }
                        ?>
                    </select>
                    <select class="" name="bulan_lahir" id="bulan_lahir" required>
                        <option value="">MM</option>
                        <?php
                        $bulan_options = array(
                            '01' => 'Januari',
                            '02' => 'Februari',
                            '03' => 'Maret',
                            '04' => 'April',
                            '05' => 'Mei',
                            '06' => 'Juni',
                            '07' => 'Juli',
                            '08' => 'Agustus',
                            '09' => 'September',
                            '10' => 'Oktober',
                            '11' => 'November',
                            '12' => 'Desember',
                        );

                        foreach ($bulan_options as $key => $value) {
                            echo "<option value='$key'>$value</option>";
                        }
                        ?>
                    </select>
                    <select class="" name="tahun_lahir" id="tahun_lahir" required>
                        <option value="">YYYY</option>
                        <?php
                        $tahun_sekarang = date("Y");
                        for ($tahun = $tahun_sekarang; $tahun >= 1980; $tahun--) {
                            echo "<option value='$tahun'>$tahun</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label>Jenis Kelamin:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki" value="Laki-laki" required>
                    <label class="form-check-label" for="laki">Laki-laki</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="Perempuan" required>
                    <label class="form-check-label" for="perempuan">Perempuan</label>
                </div>
            </div>
            <div class="form-group">
                <label for="hobi">Hobi:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobi[]" id="hobi1" value="Renang">
                    <label class="form-check-label" for="hobi1">Renang</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobi[]" id="hobi2" value="Membaca">
                    <label class="form-check-label" for="hobi2">Membaca</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobi[]" id="hobi3" value="Olahraga">
                    <label class="form-check-label" for="hobi3">Olahraga</label>
                </div>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea class="form-control" name="alamat" id="alamat" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>

<?php
        break;
    case 'edit':
        # form edit
        $nim = $_GET['nim'];
        $query = "SELECT * FROM mahasiswa WHERE nim='$nim'";
        $result = $db->query($query);
        $row = $result->fetch_assoc();

        // Pisahkan tanggal, bulan, dan tahun dari tgl_lahir
        list($tahun_lahir, $bulan_lahir, $tanggal_lahir) = explode('-', $row['tgl_lahir']);   

?>
<h2>Edit Mahasiswa</h2>
        <form action="proses_mahasiswa.php?proses=update" method="POST">
            <input type="hidden" name="nim" value="<?php echo $row['nim']; ?>">
            <div class="form-group">
                <label for="nama_mhs">Nama:</label>
                <input type="text" class="form-control" name="nama_mhs" id="nama_mhs" value="<?php echo $row['nama_mhs']; ?>" required>
            </div>

            <div class="form-group">
                <label for="prodi">Program Prodi:</label>
               <select name="prodi_id" id="prodi" class="form-select">
                <option value="">-Pilih Prodi-</option>
                <?php 
                $prodi=mysqli_query($db,"SELECT * FROM prodi");
                while ($data_prodi=mysqli_fetch_array($prodi)){
                    $selected = ($data_prodi['id'] == $row['prodi_id']) ? 'selected' : '';
                        echo "<option value=".$data_prodi['id']." $selected>".$data_prodi['nama_prodi']." </option>";
                }
                ?>
               </select>
            </div>

            <div class="form-group">
                <label for="tgl_lahir">Tanggal Lahir:</label>
                <div class="form-inline">
                    <select class="" name="tanggal_lahir" id="tanggal_lahir" required>
                        <?php
                        for ($i = 1; $i <= 31; $i++) {
                            $selected = ($i == $tanggal_lahir) ? 'selected' : '';
                            echo "<option value='$i' $selected>$i</option>";
                        }
                        ?>
                    </select>
                    <select class="" name="bulan_lahir" id="bulan_lahir" required>
                        <?php
                        $bulan_options = array(
                            '01' => 'Januari',
                            '02' => 'Februari',
                            '03' => 'Maret',
                            '04' => 'April',
                            '05' => 'Mei',
                            '06' => 'Juni',
                            '07' => 'Juli',
                            '08' => 'Agustus',
                            '09' => 'September',
                            '10' => 'Oktober',
                            '11' => 'November',
                            '12' => 'Desember',
                        );

                        foreach ($bulan_options as $key => $value) {
                            $selected = ($key == $bulan_lahir) ? 'selected' : '';
                            echo "<option value='$key' $selected>$value</option>";
                        }
                        ?>
                    </select>
                    <select class="" name="tahun_lahir" id="tahun_lahir" required>
                        <?php
                        $tahun_sekarang = date("Y");
                        for ($tahun = $tahun_sekarang; $tahun >= 1980; $tahun--) {
                            $selected = ($tahun == $tahun_lahir) ? 'selected' : '';
                            echo "<option value='$tahun' $selected>$tahun</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label>Jenis Kelamin:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="laki" value="Laki-laki" required <?php if ($row['jenis_kelamin'] == 'Laki-laki') echo 'checked'; ?>>
                    <label class="form-check-label" for="laki">Laki-laki</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="jenis_kelamin" id="perempuan" value="Perempuan" required <?php if ($row['jenis_kelamin'] == 'Perempuan') echo 'checked'; ?>>
                    <label class="form-check-label" for="perempuan">Perempuan</label>
                </div>
            </div>
            <div class="form-group">
                <label for="hobi">Hobi:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobi[]" id="hobi1" value="Renang" <?php if (in_array('Renang', explode(', ', $row['hobi']))) echo 'checked'; ?>>
                    <label class="form-check-label" for="hobi1">Renang</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobi[]" id="hobi2" value="Membaca" <?php if (in_array('Membaca', explode(', ', $row['hobi']))) echo 'checked'; ?>>
                    <label class="form-check-label" for="hobi2">Membaca</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="hobi[]" id="hobi3" value="Olahraga" <?php if (in_array('Olahraga', explode(', ', $row['hobi']))) echo 'checked'; ?>>
                    <label class="form-check-label" for="hobi3">Olahraga</label>
                </div>
            </div>
            <div class="form-group">
                <label for="alamat">Alamat:</label>
                <textarea class="form-control" name="alamat" id="alamat" required><?php echo $row['alamat']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary mt-2">Update</button>
            <a href="index.php" class="btn btn-warning mt-2">Kembali</a>
        </form>

<?php
        break;
}
?>

