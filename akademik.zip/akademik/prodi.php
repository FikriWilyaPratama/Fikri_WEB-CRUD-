<?php
    $aksi=isset($_GET['aksi']) ? $_GET['aksi'] : 'list';
    switch ($aksi) {
        case 'list':
            #List Prodi
?>

<h2>List Program Studi</h2>

        <table class="table table-bordered table-warning">
            <tr>
                <th>No</th>
                <th>Nama Program Studi</th>
                <th>Jenjang Studi</th>
                <th>Keterangan</th>
                <th>Aksi</th>
            </tr>
            <?php
            $query = "SELECT * FROM prodi ORDER BY nama_prodi";
            $result = $db->query($query);

            $no=1;
            foreach ($result as $row): ?>
            <tr>
                
                <td><?= $no++ ?></td>
                <td><?= $row['nama_prodi'] ?></td>
                <td><?= $row['jenjang_studi'] ?></td>
                <td><?= $row['keterangan'] ?></td>

                <td>
                <a class="btn btn-warning" href="index.php?page=prodi&aksi=edit&id=<?=$row['id']?>">Edit</a>
                <a class="btn btn-danger" onclick="return confirm('Ingin menghapus data?')" href="proses_prodi.php?proses=delete&id=<?=$row['id']?>">Hapus</a>
                </td>
                
            </tr>
                <?php endforeach ?>
        </table>
        <a class="btn btn-primary" href="index.php?page=prodi&aksi=input">Input Data Program Studi</a>

<?php
            break;
        case 'input':
            #Form Input Prodi
?>

<div class="container">
    <form method="POST" action="proses_prodi.php?proses=insert">
            <h1>Input Program Studi</h1>
            <table>
            <tr>
            <td>Nama Program Studi</td>
            <td><input type="text" name="nama_prodi" size="20"></td>
            </tr>

                <tr>
                    <td>Jenjang Studi</td>
                    <td>
                            <select name="jenjang_studi" required>
                            <option value="">--Pilih Jenjang Studi--</option>
                            <option value="D3">D3</option>
                            <option value="D4">D4</option>
                            <option value="S1">S1</option>
                            <option value="S2">S2</option>
                        </select>
                    </td>
                </tr>

                <tr>
                <td>Keterangan</td>
                <td><textarea rows="6" name="keterangan" cols="50"></textarea>
                </td>
                </tr>
            </table>
            <input class="btn btn-primary" type="submit" name="submit"><input class="btn btn-warning" type="reset" name="reset">
    </form>
</div>

<?php
            break;
        case 'edit':
            # Edit Prodi

            $id = $_GET['id'];
            $query="SELECT * FROM prodi where id = $id";
            $result = $db->query($query);

            if ($result->num_rows == 1){
                    $data = $result->fetch_assoc();
                    $nama_prodi = $data['nama_prodi'];
                    $jenjang_studi = $data['jenjang_studi'];
                    $keterangan=$data['keterangan'];
            } else {
                echo "Data tidak ditemukan";
                exit;
            }
?>

<div class="container">
    <h2>Edit Program Studi</h2>
    <table width="100%" border="0">
    <form action="proses_prodi.php?proses=update" method="POST">
    <input type="hidden" name="id" value="<?=$id?>">
            <tr>
                <td>Nama Program Studi</td>
                <td><input type="nama_prodi" name="nama_prodi" value="<?=$nama_prodi?>"></td>
            </tr>
            <tr>
                <td>Jenjang Studi</td>
                <td>
                    <input class="form-check-input" type="radio" name="jenjang_studi" value="D3" <?php echo ($jenjang_studi == "D3")?"checked":"" ?>> D3  
                    <input class="form-check-input" type="radio" name="jenjang_studi" value="D4" <?php echo ($jenjang_studi == "D4")?"checked":"" ?>> D4
                    <input class="form-check-input" type="radio" name="jenjang_studi" value="S1" <?php echo ($jenjang_studi == "S1")?"checked":"" ?>> S1  
                    <input class="form-check-input" type="radio" name="jenjang_studi" value="S2" <?php echo ($jenjang_studi == "S2")?"checked":"" ?>> S2
                </td>
            </tr>
            <tr>
                <td>Keterangan</td>
                <td><textarea name="keterangan" cols="40" rows="6"><?=$keterangan?></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td><input class="btn btn-primary" type="submit" name="submit" value="Update"></td>
            </tr>
            </form>
        </table>
        </div>
<?php
            break;
    }
?>