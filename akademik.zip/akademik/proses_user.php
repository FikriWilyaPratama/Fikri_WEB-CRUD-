<?php
include 'koneksi.php';
if ($_GET['proses'] == 'insert') {
        // query insert
    
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $nama = $_POST['nama'];
    $password = md5($_POST['password']);
    $level = $_POST['level'];
    
    $cek_user = "SELECT * FROM user WHERE username='$username'";
    $hasil_cek = $db->query($cek_user);

    if($hasil_cek->num_rows==1){
            echo "Data Gagal Disimpan! Duplicate ".$username;
    }else{
    
    $query = "INSERT INTO user (username, nama, password, level)  VALUES ('$username', '$nama', '$password','$level')";
    if ($db->query($query) === TRUE) {
        header("Location: index.php?page=user"); //redirect
        exit;
    } else {
        echo "Error: " . $query . "<br>" . $db->error;
    }
}
}  
}

if ($_GET['proses'] == 'update') {
    // query update
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $nama = $_POST['nama'];
        $level = $_POST['level'];
        $password = md5($_POST['password']);
        if (!empty($_POST['password'])) {
            if ($_POST['password']== $_POST['confirm']) {
                $query = "UPDATE user SET nama='$nama', level='$level', password='$password' WHERE username='$username'";         
            }
            else{
                Die('Password tidak cocok dengan confirm password');
            }
            
        }
        else {
                
            $query = "UPDATE user SET nama='$nama', level='$level' WHERE username='$username'";
        }
        if ($db->query($query) === TRUE) {
            header("Location: index.php?page=user"); //redirect
            exit;
        } else {
            echo "Error: " . $query . "<br>" . $db->error;
        }
    }

}

if ($_GET['proses'] == 'delete') {
    // query delete
    
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $username = $_GET['username'];

    // Hapus data user berdasarkan nama
    $query = "DELETE FROM user WHERE username='$username'";
    if ($db->query($query) === TRUE) {
        header("Location: index.php?page=user");
        exit;
    } else {
        echo "Error: " . $query . "<br>" . $db->error;
    }
}
}